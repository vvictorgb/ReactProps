import "../style/cabecera.css"
export default function Cabecera(){
return (
    <div className="cabecera">NATIONAL DWC POKEDEX</div>
)
}
